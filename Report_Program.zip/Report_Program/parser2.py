import re
import sys
import logging
import logging.handlers
from datetime import datetime
import configparser
from re import *
import json
import os


# Set up logging (in this case to terminal OUTPUT)
log = logging.getLogger(__name__)
log.root.setLevel(logging.DEBUG)
log_formatter = logging.Formatter('%(levelname)s %(message)s')
log_handler = logging.StreamHandler()
log_handler.setFormatter(log_formatter)
log.addHandler(log_handler)


def read_file(file_name):
    #logging.info('YES')
    logging.info('IN THE METHOD %s' % (file_name))
    #logging.info('THE VAL PARSED=' +str(file_name))
    try:
        with open(file_name, 'r') as f:
            data = f.read()
        return data
    except Exception as e:
        logging.error('Error reading file ' + file_name +
                  '. Cannot continue. Exception: ' + str(e))
    


def open_File(data):
    if data is not None:
        logging.info('DATA LEN ' + str(len(data)) + "\n" + str('DATA VAL ')  + str(data) + "\n")
    else:
        logging.error('NO DATA PROVIDED ERROR ON LINE 39')

    logging.info('DATA TYPE IS ' + str(type(data)))
    counter=0
    #logging.info('IN method open_File ' + str(data))
    #counter=0
    #print(data)
    '''
    try:
        my_file = open('file.txt','r')
        print('FILE OPENED OK')
        #call the metho
        d = {}
        for line in my_file:
            print(str(line) + str(counter))
            var = None
            #g = re.search(r'(\d+)\s+(.*)', i) # glob line containing an int and a string
            #d[int(g.group(1))] = g.group(2)
            ++counter    
    except Exception as e:
        print('ERROR' + str(e.args))
    
    finally:
        my_file.close()
    '''


def main():
    '''
    LOG_TYPE = input param
    '''
    #logging.info('IN MAIN')
    FILE_NAME=str(sys.argv[1])
    #print("MAIN")
    if FILE_NAME == 'removed.txt':
    # obj1.createToken()
    #    obj1.userLogin()
        #var_filename='/home/madlinux/Desktop/EMID/result.txt'
        print('FILE NAME PROVIDED IS ' +  str(FILE_NAME))
        #open_File(FILE_NAME)
        open_File(read_file(FILE_NAME))
    else:
        print('ERROR')

if __name__ == "__main__":
    main()















