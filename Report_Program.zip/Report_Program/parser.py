
fileA='removed.txt'
dictA={}

try:
	with open(fileA) as fd:
		for line in fd:
			(key,value)=line.split()
			dict[int(key)]=value
except Exception as e:
	print(e.args)



